<?php
session_start();
require_once '../config/db_connect.php';

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../index.php');
    exit;
}

// Obtener datos del usuario actual
$usuario_id = $_SESSION['usuario_id'];
$nombre_usuario = $_SESSION['nombre'];
$rol_usuario = $_SESSION['rol'];

// Procesar acciones AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    switch ($_POST['action']) {
        case 'obtener_calendario':
            try {
                // Obtener parámetros de fecha o usar valores por defecto
                $fecha_inicio = isset($_POST['fecha_inicio']) ? $_POST['fecha_inicio'] : date('Y-m-01');
                $fecha_fin = isset($_POST['fecha_fin']) ? $_POST['fecha_fin'] : date('Y-m-t');
                
                // Verificar que existan agrupaciones
                $query_agrupaciones = "SELECT id, nombre FROM agrupaciones ORDER BY nombre ASC";
                $result_agrupaciones = mysqli_query($conn, $query_agrupaciones);
                
                if (!$result_agrupaciones) {
                    echo json_encode([
                        'success' => false, 
                        'message' => 'Error al consultar agrupaciones: ' . mysqli_error($conn)
                    ]);
                    exit;
                }
                
                if (mysqli_num_rows($result_agrupaciones) == 0) {
                    echo json_encode([
                        'success' => false, 
                        'message' => 'No se encontraron agrupaciones en la base de datos'
                    ]);
                    exit;
                }
                
                $calendario = [];
                while ($agrupacion = mysqli_fetch_assoc($result_agrupaciones)) {
                    $id_agrupacion = $agrupacion['id'];
                    
                    $dias = [];
                    $fecha_actual = new DateTime($fecha_inicio);
                    $fecha_final = new DateTime($fecha_fin);
                    
                    while ($fecha_actual <= $fecha_final) {
                        $fecha_str = $fecha_actual->format('Y-m-d');
                        $estado = 'Libre';
                        $descripcion = '';
                        $color_temporada = '#ffffff';
                        $nombre_temporada = '';
                        $tipo_reserva = null;
                        $reserva_id = null;
                        $huesped_nombre = '';
                        
                        // Obtener información de temporada
                        $query_temporada = "SELECT nombre, color FROM temporadas 
                                           WHERE '$fecha_str' BETWEEN fecha_inicio AND fecha_fin
                                           LIMIT 1";
                        $result_temporada = mysqli_query($conn, $query_temporada);
                        
                        if ($result_temporada && ($temporada = mysqli_fetch_assoc($result_temporada))) {
                            $color_temporada = $temporada['color'];
                            $nombre_temporada = $temporada['nombre'];
                        }
                        
                        // Verificar reservas activas y obtener información detallada
                        $query_reservas_agrupacion = "SELECT r.id, r.tipo_reserva, h.nombre as huesped_nombre,
                                                     COUNT(*) as num_reservas
                                                     FROM reservas r
                                                     INNER JOIN huespedes h ON r.id_huesped = h.id
                                                     WHERE r.id_agrupacion = $id_agrupacion
                                                     AND '$fecha_str' >= r.start_date 
                                                     AND '$fecha_str' < r.end_date
                                                     AND r.status IN ('confirmada', 'activa')
                                                     GROUP BY r.id, r.tipo_reserva, h.nombre
                                                     LIMIT 1";
                        $result_reservas_agrupacion = mysqli_query($conn, $query_reservas_agrupacion);
                        
                        if ($result_reservas_agrupacion && mysqli_num_rows($result_reservas_agrupacion) > 0) {
                            $reserva_info = mysqli_fetch_assoc($result_reservas_agrupacion);
                            $estado = 'Reservado';
                            $reserva_id = $reserva_info['id'];
                            $tipo_reserva = $reserva_info['tipo_reserva'];
                            $huesped_nombre = $reserva_info['huesped_nombre'];
                            $descripcion = "Reserva #$reserva_id - $huesped_nombre";
                        }
                        
                        $dias[] = [
                            'fecha' => $fecha_str,
                            'estado' => $estado,
                            'descripcion' => $descripcion,
                            'color_temporada' => $color_temporada,
                            'nombre_temporada' => $nombre_temporada,
                            'tipo_reserva' => $tipo_reserva,
                            'reserva_id' => $reserva_id,
                            'huesped_nombre' => $huesped_nombre
                        ];
                        
                        $fecha_actual->add(new DateInterval('P1D'));
                    }
                    
                    $calendario[] = [
                        'id' => $agrupacion['id'],
                        'nombre' => $agrupacion['nombre'],
                        'dias' => $dias
                    ];
                }
                
                echo json_encode([
                    'success' => true, 
                    'calendario' => $calendario, 
                    'fecha_inicio' => $fecha_inicio,
                    'fecha_fin' => $fecha_fin,
                    'total_agrupaciones' => count($calendario)
                ]);
                
            } catch (Exception $e) {
                echo json_encode([
                    'success' => false, 
                    'message' => 'Error interno: ' . $e->getMessage()
                ]);
            }
            exit;

        case 'obtener_temporadas_activas':
            $fecha_actual = date('Y-m-d');
            $fecha_45_dias = date('Y-m-d', strtotime('+45 days'));
            
            $query_temporadas = "SELECT DISTINCT nombre, color 
                                FROM temporadas 
                                WHERE ((fecha_inicio BETWEEN '$fecha_actual' AND '$fecha_45_dias')
                                OR (fecha_fin BETWEEN '$fecha_actual' AND '$fecha_45_dias')
                                OR ('$fecha_actual' BETWEEN fecha_inicio AND fecha_fin))
                                ORDER BY fecha_inicio ASC";
            
            $result_temporadas = mysqli_query($conn, $query_temporadas);
            
            if (!$result_temporadas) {
                echo json_encode(['success' => false, 'message' => 'Error consultando temporadas: ' . mysqli_error($conn)]);
                exit;
            }
            
            $temporadas = [];
            while ($temporada = mysqli_fetch_assoc($result_temporadas)) {
                $temporadas[] = $temporada;
            }
            
            echo json_encode(['success' => true, 'temporadas' => $temporadas]);
            exit;

        case 'obtener_reserva_detalle':
            try {
                $id_reserva = (int)$_POST['id_reserva'];
                
                if ($id_reserva <= 0) {
                    echo json_encode(['success' => false, 'message' => 'ID de reserva inválido']);
                    exit;
                }
                
                // Obtener datos básicos de la reserva
                $query_reserva = "SELECT r.*, h.nombre as huesped_nombre, h.telefono as huesped_telefono, 
                                         h.correo as huesped_correo, a.nombre as agrupacion_nombre,
                                         u.nombre as usuario_nombre
                                 FROM reservas r
                                 INNER JOIN huespedes h ON r.id_huesped = h.id
                                 INNER JOIN agrupaciones a ON r.id_agrupacion = a.id
                                 INNER JOIN usuarios u ON r.id_usuario = u.id
                                 WHERE r.id = ?";
                
                $stmt = mysqli_prepare($conn, $query_reserva);
                if (!$stmt) {
                    throw new Exception('Error al preparar consulta de reserva: ' . mysqli_error($conn));
                }
                
                mysqli_stmt_bind_param($stmt, 'i', $id_reserva);
                
                if (!mysqli_stmt_execute($stmt)) {
                    throw new Exception('Error al ejecutar consulta de reserva: ' . mysqli_stmt_error($stmt));
                }
                
                $result = mysqli_stmt_get_result($stmt);
                $reserva = mysqli_fetch_assoc($result);
                mysqli_stmt_close($stmt);
                
                if (!$reserva) {
                    echo json_encode(['success' => false, 'message' => 'Reserva no encontrada']);
                    exit;
                }
                
                // Obtener pagos de la reserva
                $query_pagos = "SELECT * FROM pagos WHERE id_reserva = ? ORDER BY fecha_pago ASC";
                $stmt = mysqli_prepare($conn, $query_pagos);
                mysqli_stmt_bind_param($stmt, 'i', $id_reserva);
                mysqli_stmt_execute($stmt);
                $result_pagos = mysqli_stmt_get_result($stmt);
                
                $pagos = [];
                while ($pago = mysqli_fetch_assoc($result_pagos)) {
                    $pagos[] = $pago;
                }
                mysqli_stmt_close($stmt);
                
                // Obtener personas adicionales
                $query_personas = "SELECT * FROM reserva_personas WHERE id_reserva = ? ORDER BY id ASC";
                $stmt = mysqli_prepare($conn, $query_personas);
                mysqli_stmt_bind_param($stmt, 'i', $id_reserva);
                mysqli_stmt_execute($stmt);
                $result_personas = mysqli_stmt_get_result($stmt);
                
                $personas = [];
                while ($persona = mysqli_fetch_assoc($result_personas)) {
                    $personas[] = $persona;
                }
                mysqli_stmt_close($stmt);
                
                // Obtener artículos
                $query_articulos = "SELECT * FROM reserva_articulos WHERE id_reserva = ? ORDER BY id ASC";
                $stmt = mysqli_prepare($conn, $query_articulos);
                mysqli_stmt_bind_param($stmt, 'i', $id_reserva);
                mysqli_stmt_execute($stmt);
                $result_articulos = mysqli_stmt_get_result($stmt);
                
                $articulos = [];
                while ($articulo = mysqli_fetch_assoc($result_articulos)) {
                    $articulos[] = $articulo;
                }
                mysqli_stmt_close($stmt);
                
                echo json_encode([
                    'success' => true,
                    'reserva' => $reserva,
                    'pagos' => $pagos,
                    'personas' => $personas,
                    'articulos' => $articulos
                ]);
                
            } catch (Exception $e) {
                error_log("Error en obtener_reserva_detalle: " . $e->getMessage());
                echo json_encode([
                    'success' => false,
                    'message' => 'Error interno del servidor: ' . $e->getMessage()
                ]);
            }
            exit;

        default:
            echo json_encode(['success' => false, 'message' => 'Acción no válida']);
            exit;
    }
}

// Obtener agrupaciones para el calendario inicial
$agrupaciones_disponibles = [];
$mensaje_error = '';

try {
    $query_agrupaciones = "SELECT id, nombre FROM agrupaciones ORDER BY nombre ASC";
    $result_agrupaciones = mysqli_query($conn, $query_agrupaciones);
    
    if ($result_agrupaciones && mysqli_num_rows($result_agrupaciones) > 0) {
        while ($agrupacion = mysqli_fetch_assoc($result_agrupaciones)) {
            $agrupaciones_disponibles[] = $agrupacion;
        }
    } else {
        $mensaje_error = 'No se encontraron agrupaciones en la base de datos.';
    }
    
} catch (Exception $e) {
    $mensaje_error = 'Error al cargar agrupaciones: ' . $e->getMessage();
    error_log("Error cargando agrupaciones: " . $e->getMessage());
}

// Obtener estadísticas
$stats = [];
$stats['total_agrupaciones'] = count($agrupaciones_disponibles);

// Reservas de hoy
$hoy = date('Y-m-d');
try {
    $query_reservas_hoy = "SELECT COUNT(*) as total FROM reservas WHERE start_date = '$hoy' AND status IN ('confirmada', 'activa')";
    $result_reservas_hoy = mysqli_query($conn, $query_reservas_hoy);
    if ($result_reservas_hoy) {
        $stats['reservas_hoy'] = mysqli_fetch_assoc($result_reservas_hoy)['total'];
    } else {
        $stats['reservas_hoy'] = 0;
    }
} catch (Exception $e) {
    $stats['reservas_hoy'] = 0;
}

// Ocupación actual
try {
    $query_ocupadas = "SELECT COUNT(DISTINCT r.id_agrupacion) as ocupadas 
                      FROM reservas r 
                      WHERE '$hoy' >= r.start_date 
                      AND '$hoy' < r.end_date 
                      AND r.status IN ('confirmada', 'activa')";
    $result_ocupadas = mysqli_query($conn, $query_ocupadas);
    if ($result_ocupadas) {
        $stats['ocupadas'] = mysqli_fetch_assoc($result_ocupadas)['ocupadas'];
    } else {
        $stats['ocupadas'] = 0;
    }
} catch (Exception $e) {
    $stats['ocupadas'] = 0;
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendario de Reservas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .calendario-container {
            overflow-x: auto;
        }
        .dia-calendario {
            position: relative;
            min-width: 100px;
            min-height: 60px;
            text-align: center;
            cursor: pointer;
            border: 1px solid #ddd;
            padding: 8px 5px;
            vertical-align: top;
        }
        .can-reserve:hover {
            background-color: #e9ecef;
        }
        .estado-libre { background-color: #d4edda; }
        .estado-reservado { background-color: #f8d7da; }
        .estado-apartado { background-color: #fff3cd; }
        .estado-ocupado { background-color: #d1ecf1; }
        .estado-mantenimiento { background-color: #f4cccc; }
        .estado-limpieza { background-color: #e2e3e5; }

        .calendario-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 8px;
        }

        .mes-navegacion {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .btn-mes {
            background: #007bff;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        .btn-mes:hover {
            background: #0056b3;
        }

        .btn-mes:disabled {
            background: #6c757d;
            cursor: not-allowed;
        }

        .mes-actual {
            font-size: 18px;
            font-weight: bold;
            color: #333;
            min-width: 200px;
            text-align: center;
        }

        .tipo-walking {
            background-color: #ff8c00 !important;
            color: white;
        }

        .tipo-previa {
            background-color: #ffd700 !important;
            color: black;
        }

        .temporada-indicator {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            margin: 2px auto 0;
            border: 1px solid rgba(0,0,0,0.2);
        }

        .fecha-numero {
            font-weight: bold;
            font-size: 12px;
            margin-bottom: 2px;
        }

        .estado-texto {
            font-size: 10px;
            margin-bottom: 2px;
        }

        .calendario-fechas-header {
            background: #e9ecef;
            font-weight: bold;
            font-size: 11px;
            text-align: center;
            padding: 8px 5px;
            border: 1px solid #ddd;
        }

        .sticky-left {
            position: sticky;
            left: 0;
            z-index: 15;
            background: #f8f9fa;
            border-right: 2px solid #007bff;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            min-width: 150px;
            max-width: 200px;
        }

        .table thead th.sticky-left {
            z-index: 20;
            background: #e9ecef;
            font-weight: bold;
        }

        .table {
            margin-bottom: 0;
            white-space: nowrap;
        }

        .habitacion-nombre {
            padding: 12px 15px;
            font-weight: 600;
            color: #495057;
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border-right: 2px solid #007bff !important;
            vertical-align: middle;
            text-align: left;
        }

        .table tbody tr:hover .habitacion-nombre {
            background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%);
            color: #1976d2;
        }

        .view-reservation-btn {
            border: 1px solid !important;
            border-radius: 3px !important;
            font-size: 8px !important;
            padding: 1px 4px !important;
            line-height: 1 !important;
            min-width: 20px;
            height: 16px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }
        .view-reservation-btn:hover {
            background-color: #17a2b8 !important;
            color: white !important;
            border-color: #17a2b8 !important;
        }

        /* Estilo para el botón de editar reserva */
        .edit-reservation-btn {
            border: 1px solid !important;
            border-radius: 3px !important;
            font-size: 8px !important;
            padding: 1px 4px !important;
            line-height: 1 !important;
            min-width: 20px;
            height: 16px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }
        .edit-reservation-btn:hover {
            background-color: #007bff !important;
            color: white !important;
            border-color: #007bff !important;
        }

        .reserva-info {
            line-height: 1.1;
            margin: 2px 0;
        }
        .reserva-botones {
            display: flex;
            justify-content: center;
            gap: 2px;
            margin-top: 2px;
        }
        .swal2-popup.text-start {
            text-align: left !important;
        }
        .swal2-popup.text-start .swal2-title {
            text-align: center !important;
        }
        .swal2-popup .table {
            font-size: 12px;
        }
        .swal2-popup .table th, .swal2-popup .table td {
            padding: 4px 8px;
            vertical-align: middle;
        }
        .swal2-popup .card {
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            border: 1px solid #dee2e6;
        }
        .swal2-popup .card-body {
            font-size: 11px;
            line-height: 1.3;
        }
        @media (max-width: 768px) {
            .dia-calendario {
                min-width: 80px;
                min-height: 50px;
                padding: 5px 3px;
            }
            .mes-actual {
                font-size: 16px;
                min-width: 150px;
            }
            .calendario-header {
                flex-direction: column;
                gap: 15px;
            }
        }
    </style>
</head>
<body>
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center py-3">
                    <h2><i class="fas fa-calendar-alt me-2"></i>Calendario de Reservas</h2>
                    <div class="d-flex gap-2">
                        <span class="badge bg-primary">Agrupaciones: <?php echo $stats['total_agrupaciones']; ?></span>
                        <span class="badge bg-success">Reservas Hoy: <?php echo $stats['reservas_hoy']; ?></span>
                        <span class="badge bg-warning">Ocupadas: <?php echo $stats['ocupadas']; ?></span>
                        <a href="nreserva.php" class="btn btn-success btn-sm">
                            <i class="fas fa-plus me-1"></i>Nueva Reserva
                        </a>
                    </div>
                </div>
                <?php if (!empty($mensaje_error)): ?>
                    <div class="alert alert-danger">
                        <h5><i class="fas fa-exclamation-triangle me-2"></i>Error de Configuración</h5>
                        <p><?php echo htmlspecialchars($mensaje_error); ?></p>
                    </div>
                <?php endif; ?>
                <!-- Leyenda de temporadas -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-palette me-2"></i>Temporadas Activas</h5>
                    </div>
                    <div class="card-body">
                        <div id="leyendaTemporadas">
                            <span class="badge bg-secondary">Cargando temporadas...</span>
                        </div>
                    </div>
                </div>
                <!-- Calendario -->
                <div class="card">
                    <div class="card-header">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h5 class="mb-0"><i class="fas fa-calendar me-2"></i>Calendario de Reservas</h5>
                                <small class="text-muted">Haga clic en una fecha libre para crear una reserva | Haga clic en "Ver" para ver detalles | Haga clic en "Editar" para modificar una reserva</small>
                            </div>
                            <div class="d-flex gap-2 align-items-center">
                                <span class="badge tipo-previa">Reservación Previa</span>
                                <span class="badge tipo-walking">Walking</span>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <!-- Navegación de meses -->
                        <div class="calendario-header">
                            <div class="mes-navegacion">
                                <button class="btn-mes" id="btnMesAnterior">
                                    <i class="fas fa-chevron-left"></i>
                                </button>
                                <div class="mes-actual" id="mesActual">
                                    <!-- Se llena dinámicamente -->
                                </div>
                                <button class="btn-mes" id="btnMesSiguiente">
                                    <i class="fas fa-chevron-right"></i>
                                </button>
                            </div>
                            <div>
                                <button class="btn btn-outline-primary btn-sm" onClick="refrescarCalendario()">
                                    <i class="fas fa-sync-alt"></i> Actualizar
                                </button>
                            </div>
                        </div>
                        <div class="calendario-container">
                            <table class="table table-bordered table-sm table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <!-- Las fechas se generarán dinámicamente -->
                                    </tr>
                                </thead>
                                <tbody id="calendarioBody">
                                    <?php if (empty($agrupaciones_disponibles)): ?>
                                        <tr>
                                            <td colspan="100%" class="text-center text-muted py-4">
                                                <i class="fas fa-info-circle me-2"></i> No hay agrupaciones disponibles para mostrar el calendario
                                            </td>
                                        </tr>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="100%" class="text-center text-muted py-4">
                                                <i class="fas fa-spinner fa-spin me-2"></i> Cargando calendario...
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        let fechaCalendarioActual = new Date(); // Fecha actual para la navegación del calendario

        $(document).ready(function() {
            cargarCalendario();
            cargarLeyendaTemporadas();

            // Navegación de meses
            $('#btnMesAnterior').on('click', function() {
                if (!$(this).prop('disabled')) {
                    fechaCalendarioActual.setMonth(fechaCalendarioActual.getMonth() - 1);
                    cargarCalendario();
                }
            });

            $('#btnMesSiguiente').on('click', function() {
                if (!$(this).prop('disabled')) {
                    fechaCalendarioActual.setMonth(fechaCalendarioActual.getMonth() + 1);
                    cargarCalendario();
                }
            });

            // Manejar clic en celda del calendario para nueva reserva
            $(document).on('click', '.dia-calendario.can-reserve', function() {
                var idAgrupacion = $(this).data('id_agrupacion');
                var nombreAgrupacion = $(this).data('nombre_agrupacion');
                var fechaSeleccionada = $(this).data('fecha');

                // Redirigir a nueva reserva con parámetros
                window.location.href = `nreserva.php?agrupacion=${idAgrupacion}&fecha=${fechaSeleccionada}&nombre=${encodeURIComponent(nombreAgrupacion)}`;
            });

            // Manejar clic en el botón de "Ver" reserva
            $(document).on('click', '.view-reservation-btn', function(e) {
                e.stopPropagation(); // Evitar que el clic se propague a la celda del calendario
                var reservaId = $(this).data('reserva_id');
                mostrarDetallesReserva(reservaId);
            });

            // Manejar clic en el botón de "Editar" reserva
            $(document).on('click', '.edit-reservation-btn', function(e) {
                e.stopPropagation(); // Evitar que el clic se propague a la celda del calendario
                var reservaId = $(this).data('reserva_id');
                window.location.href = `ereserva.php?id=${reservaId}`;
            });

            // Función para refrescar calendario
            window.refrescarCalendario = function() {
                cargarCalendario();
                cargarLeyendaTemporadas();
            };

            // Auto-refresh cada 5 minutos
            setInterval(function() {
                cargarCalendario();
            }, 300000);
        });

        function cargarCalendario() {
            const fechaInicioMes = new Date(fechaCalendarioActual.getFullYear(), fechaCalendarioActual.getMonth(), 1);
            const fechaFinMes = new Date(fechaCalendarioActual.getFullYear(), fechaCalendarioActual.getMonth() + 1, 0);

            $('#mesActual').text(fechaCalendarioActual.toLocaleString('es-ES', { month: 'long', year: 'numeric' }).toUpperCase());
            $('#calendarioBody').html('<tr><td colspan="100%" class="text-center text-muted py-4"><i class="fas fa-spinner fa-spin me-2"></i> Cargando calendario...</td></tr>');

            $.ajax({
                url: 'reserva.php', // Apunta al mismo archivo PHP que maneja las acciones AJAX
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'obtener_calendario',
                    fecha_inicio: fechaInicioMes.toISOString().slice(0, 10),
                    fecha_fin: fechaFinMes.toISOString().slice(0, 10)
                },
                success: function(response) {
                    if (response.success) {
                        renderizarCalendario(response.calendario, fechaInicioMes, fechaFinMes);
                    } else {
                        $('#calendarioBody').html(`<tr><td colspan="100%" class="text-center text-danger py-4"><i class="fas fa-exclamation-triangle me-2"></i> ${response.message}</td></tr>`);
                    }
                },
                error: function(xhr, status, error) {
                    console.error("AJAX Error: ", status, error, xhr.responseText);
                    $('#calendarioBody').html('<tr><td colspan="100%" class="text-center text-danger py-4"><i class="fas fa-exclamation-triangle me-2"></i> Error al cargar el calendario.</td></tr>');
                }
            });
        }

        function renderizarCalendario(calendario, fechaInicioMes, fechaFinMes) {
            const $thead = $('table.table thead tr');
            const $tbody = $('#calendarioBody');
            $thead.empty();
            $tbody.empty();

            // Crear encabezado de fechas
            $thead.append('<th class="sticky-left">Agrupación</th>');
            const fechas = [];
            let fechaActual = new Date(fechaInicioMes);
            while (fechaActual <= fechaFinMes) {
                const fechaStr = fechaActual.toISOString().slice(0, 10);
                const diaSemana = fechaActual.toLocaleDateString('es-ES', { weekday: 'short' });
                const diaMes = fechaActual.getDate();
                $thead.append(`<th class="calendario-fechas-header">${diaSemana}<br>${diaMes}</th>`);
                fechas.push(fechaStr);
                fechaActual.setDate(fechaActual.getDate() + 1);
            }

            // Llenar el cuerpo del calendario
            calendario.forEach(agrupacion => {
                let rowHtml = `<tr><td class="sticky-left habitacion-nombre">${agrupacion.nombre}</td>`;
                fechas.forEach(fecha => {
                    const diaInfo = agrupacion.dias.find(d => d.fecha === fecha);
                    if (diaInfo) {
                        let estadoClass = `estado-${diaInfo.estado.toLowerCase().replace(' ', '-')}`;
                        let canReserveClass = diaInfo.estado === 'Libre' ? 'can-reserve' : '';
                        let reservaInfoHtml = '';
                        let temporadaIndicator = '';

                        if (diaInfo.nombre_temporada) {
                            temporadaIndicator = `<div class="temporada-indicator" style="background-color: ${diaInfo.color_temporada};" title="${diaInfo.nombre_temporada}"></div>`;
                        }

                        if (diaInfo.reserva_id) {
                            let tipoReservaClass = '';
                            if (diaInfo.tipo_reserva === 'walking') {
                                tipoReservaClass = 'tipo-walking';
                            } else if (diaInfo.tipo_reserva === 'previa') {
                                tipoReservaClass = 'tipo-previa';
                            }

                            reservaInfoHtml = `
                                <div class="reserva-info ${tipoReservaClass}">
                                    <div>Reserva #${diaInfo.reserva_id}</div>
                                    <div>${diaInfo.huesped_nombre}</div>
                                </div>
                                <div class="reserva-botones">
                                    <button class="btn btn-info view-reservation-btn" data-reserva_id="${diaInfo.reserva_id}" title="Ver detalles">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button class="btn btn-primary edit-reservation-btn" data-reserva_id="${diaInfo.reserva_id}" title="Editar reserva">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                </div>
                            `;
                        }

                        rowHtml += `
                            <td class="dia-calendario ${estadoClass} ${canReserveClass}" 
                                data-id_agrupacion="${agrupacion.id}" 
                                data-nombre_agrupacion="${agrupacion.nombre}" 
                                data-fecha="${fecha}"
                                title="${diaInfo.descripcion || diaInfo.estado}">
                                <div class="fecha-numero">${new Date(fecha).getDate()}</div>
                                ${temporadaIndicator}
                                <div class="estado-texto">${diaInfo.estado}</div>
                                ${reservaInfoHtml}
                            </td>
                        `;
                    } else {
                        rowHtml += `<td class="dia-calendario estado-libre can-reserve" data-id_agrupacion="${agrupacion.id}" data-nombre_agrupacion="${agrupacion.nombre}" data-fecha="${fecha}">
                            <div class="fecha-numero">${new Date(fecha).getDate()}</div>
                            <div class="estado-texto">Libre</div>
                        </td>`;
                    }
                });
                rowHtml += '</tr>';
                $tbody.append(rowHtml);
            });
        }

        function cargarLeyendaTemporadas() {
            $.ajax({
                url: 'reserva.php', // Apunta al mismo archivo PHP
                type: 'POST',
                dataType: 'json',
                data: { action: 'obtener_temporadas_activas' },
                success: function(response) {
                    if (response.success && response.temporadas.length > 0) {
                        let leyendaHtml = '';
                        response.temporadas.forEach(temp => {
                            leyendaHtml += `<span class="badge me-2" style="background-color: ${temp.color}; color: ${getContrastColor(temp.color)};">${temp.nombre}</span>`;
                        });
                        $('#leyendaTemporadas').html(leyendaHtml);
                    } else {
                        $('#leyendaTemporadas').html('<span class="badge bg-secondary">No hay temporadas activas próximas.</span>');
                    }
                },
                error: function() {
                    $('#leyendaTemporadas').html('<span class="badge bg-danger">Error al cargar temporadas.</span>');
                }
            });
        }

        // Función para obtener el color de contraste (blanco o negro) para el texto de la leyenda
        function getContrastColor(hexcolor) {
            // Si el color es un nombre, devolver negro por defecto (o blanco si es muy oscuro)
            if (!hexcolor.startsWith('#')) return 'black'; 

            var r = parseInt(hexcolor.substr(1, 2), 16);
            var g = parseInt(hexcolor.substr(3, 2), 16);
            var b = parseInt(hexcolor.substr(5, 2), 16);
            var y = ((r * 299) + (g * 587) + (b * 114)) / 1000;
            return (y >= 128) ? 'black' : 'white';
        }

        function mostrarDetallesReserva(reservaId) {
            Swal.fire({
                title: 'Cargando Detalles de Reserva...',
                html: '<i class="fas fa-spinner fa-spin"></i> Por favor espere...',
                allowOutsideClick: false,
                showConfirmButton: false
            });

            $.ajax({
                url: 'reserva.php', // Apunta al mismo archivo PHP
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'obtener_reserva_detalle',
                    id_reserva: reservaId
                },
                success: function(response) {
                    Swal.close();
                    if (response.success) {
                        const reserva = response.reserva;
                        const pagos = response.pagos;
                        const personas = response.personas;
                        const articulos = response.articulos;

                        let pagosHtml = '<p>No hay pagos registrados.</p>';
                        if (pagos.length > 0) {
                            pagosHtml = `
                                <div class="table-responsive">
                                    <table class="table table-sm table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Tipo</th>
                                                <th>Monto</th>
                                                <th>Método</th>
                                                <th>Estado</th>
                                                <th>Fecha</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            ${pagos.map(p => `
                                                <tr>
                                                    <td>${p.tipo}</td>
                                                    <td>$${parseFloat(p.monto).toFixed(2)}</td>
                                                    <td>${p.metodo_pago}</td>
                                                    <td><span class="badge bg-${p.estado === 'procesado' ? 'success' : (p.estado === 'pendiente' ? 'warning' : 'danger')}">${p.estado}</span></td>
                                                    <td>${p.fecha_pago ? p.fecha_pago.substring(0, 10) : 'N/A'}</td>
                                                </tr>
                                            `).join('')}
                                        </tbody>
                                    </table>
                                </div>
                            `;
                        }

                        let personasHtml = '<p>No hay personas adicionales registradas.</p>';
                        if (personas.length > 0) {
                            personasHtml = `
                                <div class="row row-cols-1 row-cols-md-2 g-2">
                                    ${personas.map(p => `
                                        <div class="col">
                                            <div class="card card-body p-2">
                                                <strong>${p.nombre}</strong> (${p.edad} años)
                                                <small class="text-muted">${p.observaciones || 'Sin observaciones'}</small>
                                            </div>
                                        </div>
                                    `).join('')}
                                </div>
                            `;
                        }

                        let articulosHtml = '<p>No hay artículos/servicios registrados.</p>';
                        if (articulos.length > 0) {
                            articulosHtml = `
                                <div class="table-responsive">
                                    <table class="table table-sm table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Descripción</th>
                                                <th>Cant.</th>
                                                <th>Precio U.</th>
                                                <th>Total</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            ${articulos.map(a => `
                                                <tr>
                                                    <td>${a.descripcion}</td>
                                                    <td>${a.cantidad}</td>
                                                    <td>$${parseFloat(a.precio).toFixed(2)}</td>
                                                    <td>$${(parseFloat(a.cantidad) * parseFloat(a.precio)).toFixed(2)}</td>
                                                </tr>
                                            `).join('')}
                                        </tbody>
                                    </table>
                                </div>
                            `;
                        }

                        Swal.fire({
                            title: `Detalles de Reserva #${reserva.id}`,
                            html: `
                                <div class="text-start">
                                    <p><strong>Agrupación:</strong> ${reserva.agrupacion_nombre}</p>
                                    <p><strong>Huésped:</strong> ${reserva.huesped_nombre} (${reserva.huesped_telefono})</p>
                                    <p><strong>Fechas:</strong> ${reserva.start_date} al ${reserva.end_date}</p>
                                    <p><strong>Personas:</strong> ${reserva.personas_max}</p>
                                    <p><strong>Tipo de Reserva:</strong> <span class="badge ${reserva.tipo_reserva === 'walking' ? 'tipo-walking' : 'tipo-previa'}">${reserva.tipo_reserva}</span></p>
                                    <p><strong>Total Reserva:</strong> $${parseFloat(reserva.total).toFixed(2)}</p>
                                    <p><strong>Registrado por:</strong> ${reserva.usuario_nombre} el ${reserva.created_at.substring(0, 10)}</p>
                                    <hr>
                                    <h6>Pagos:</h6>
                                    ${pagosHtml}
                                    <hr>
                                    <h6>Personas Adicionales:</h6>
                                    ${personasHtml}
                                    <hr>
                                    <h6>Artículos/Servicios:</h6>
                                    ${articulosHtml}
                                </div>
                            `,
                            width: '800px',
                            showCloseButton: true,
                            showCancelButton: true,
                            cancelButtonText: 'Cerrar',
                            showConfirmButton: true,
                            confirmButtonText: '<i class="fas fa-edit"></i> Editar Reserva',
                            customClass: {
                                container: 'swal2-container',
                                popup: 'swal2-popup text-start'
                            }
                        }).then((result) => {
                            if (result.isConfirmed) {
                                window.location.href = `ereserva.php?id=${reserva.id}`;
                            }
                        });

                    } else {
                        Swal.fire('Error', response.message || 'No se pudieron obtener los detalles de la reserva.', 'error');
                    }
                },
                error: function(xhr, status, error) {
                    Swal.close();
                    console.error("Error cargando detalles de reserva: ", status, error, xhr.responseText);
                    Swal.fire('Error', 'Error de conexión al cargar los detalles de la reserva.', 'error');
                }
            });
        }

        // Función para agregar botón de editar en las celdas del calendario
        function agregarBotonEditar(cell, reservaId) {
            // Solo agregar si hay una reserva
            if (reservaId) {
                const editButton = $('<button class="btn btn-sm btn-outline-primary edit-reservation-btn mt-1" style="font-size: 10px; padding: 2px 6px;" title="Editar reserva">')
                    .html('<i class="fas fa-edit"></i>')
                    .data('reserva_id', reservaId);
                cell.find('.reserva-botones').append(editButton);
            }
        }
    </script>
</body>
</html>
